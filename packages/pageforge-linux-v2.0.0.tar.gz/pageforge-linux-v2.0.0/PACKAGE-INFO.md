# PageForge v2.0.0 - Package Linux/macOS

## Informations
- **Type**: Installation locale Linux/macOS
- **Prérequis**: PHP 7.4+, Node.js 16+ recommandé
- **Installation**: Interface web PHP ou CLI
- **Version**: 2.0.0
- **Date**: 2025-08-04 20:55:12

## Fonctionnalités
- Compatible toutes distributions Linux
- Support macOS natif
- Installation Node.js automatique
- Scripts shell optimisés
- Configuration SQLite automatique
- Mode développement intégré

## Support
Pour toute question ou problème, consultez la documentation incluse.
