#!/bin/bash
echo "Installation CLI de PageForge..."
php install.php
