# PageForge v2.0.0 - Package VS Code

## Informations
- **Type**: Environnement de développement VS Code
- **Prérequis**: PHP 7.4+, Node.js 18+, VS Code, Git
- **Installation**: Configuration automatique développement
- **Version**: 2.0.0
- **Date**: 2025-08-04 08:13:36

## Fonctionnalités
- Configuration VS Code complète
- Debug client/serveur intégré
- Extensions recommandées
- Snippets personnalisés PageForge
- Structure projet professionnelle

## Support
Pour toute question ou problème, consultez la documentation incluse.
