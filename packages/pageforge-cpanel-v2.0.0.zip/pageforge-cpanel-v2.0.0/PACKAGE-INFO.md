# PageForge v2.0.0 - Package cPanel

## Informations
- **Type**: Hébergement web cPanel
- **Prérequis**: PHP 7.4+, MySQL/PostgreSQL
- **Installation**: Interface web interactive
- **Version**: 2.0.0
- **Date**: 2025-08-04 08:13:35

## Fonctionnalités
- Installation sans ligne de commande
- Configuration automatique base de données
- Interface responsive moderne
- Nettoyage automatique post-installation

## Support
Pour toute question ou problème, consultez la documentation incluse.
