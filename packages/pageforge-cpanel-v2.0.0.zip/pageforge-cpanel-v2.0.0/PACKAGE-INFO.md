# PageForge v2.0.0 - Package cPanel

## Informations
- **Type**: Hébergement web cPanel avec Node.js Selector
- **Prérequis**: PHP 7.4+, MySQL/PostgreSQL, Node.js Selector (optionnel)
- **Installation**: Interface web interactive avec support Node.js
- **Version**: 2.0.0
- **Date**: 2025-08-04 21:15:54

## Fonctionnalités
- Installation sans ligne de commande
- Support Node.js Selector de cPanel
- Configuration automatique base de données
- Interface responsive moderne
- Optimisations hébergement partagé
- Nettoyage automatique post-installation

## Support
Pour toute question ou problème, consultez la documentation incluse.
