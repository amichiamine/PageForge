<?php
/**
 * 🚀 PAGEFORGE - INSTALLATION AUTOMATISÉE CPANEL
 * 
 * Script d'installation automatique pour hébergement cPanel
 * Compatible avec hébergements sans accès console
 * Compatible avec l'outil Node.js Selector de cPanel (voir capture)
 * 
 * INSTRUCTIONS:
 * 1. Uploadez ce fichier + pageforge-build.zip à la racine de votre hébergement
 * 2. Si disponible, activez Node.js via Node.js Selector dans cPanel
 * 3. Visitez: https://votre-domaine.com/install-cpanel.php
 * 4. Suivez les étapes d'installation
 * 5. Supprimez ce fichier après installation
 */

session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

class PageForgeInstaller {
    private $config = [];
    private $steps = [
        'welcome' => 'Bienvenue',
        'requirements' => 'Vérification des prérequis',
        'nodejs' => 'Configuration Node.js',
        'database' => 'Configuration base de données',
        'files' => 'Installation des fichiers',
        'config' => 'Configuration finale',
        'complete' => 'Installation terminée'
    ];
    
    public function __construct() {
        $this->config = [
            'app_name' => 'PageForge',
            'version' => '2.0.0',
            'min_php' => '7.4',
            'min_node' => '16.0',
            'required_extensions' => ['pdo', 'pdo_mysql', 'json', 'curl', 'zip', 'gd']
        ];
    }
    
    public function run() {
        // Gérer la suppression de l'installateur
        if (isset($_GET['action']) && $_GET['action'] === 'delete_installer') {
            unlink(__FILE__);
            echo json_encode(['success' => true]);
            exit;
        }
        
        $step = $_GET['step'] ?? 'welcome';
        
        $this->renderHeader();
        
        switch($step) {
            case 'welcome':
                $this->stepWelcome();
                break;
            case 'requirements':
                $this->stepRequirements();
                break;
            case 'nodejs':
                $this->stepNodeJS();
                break;
            case 'database':
                $this->stepDatabase();
                break;
            case 'files':
                $this->stepFiles();
                break;
            case 'config':
                $this->stepConfig();
                break;
            case 'complete':
                $this->stepComplete();
                break;
            default:
                $this->stepWelcome();
        }
        
        $this->renderFooter();
    }
    
    private function renderHeader() {
        ?>
        <!DOCTYPE html>
        <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Installation PageForge - cPanel</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { 
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                    color: #333;
                }
                .container { max-width: 900px; margin: 0 auto; padding: 20px; }
                .card { 
                    background: white; 
                    border-radius: 16px; 
                    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                    padding: 40px; 
                    margin: 20px 0; 
                    backdrop-filter: blur(10px);
                }
                .header { text-align: center; margin-bottom: 40px; }
                .logo { 
                    font-size: 3rem; 
                    font-weight: 800; 
                    background: linear-gradient(135deg, #667eea, #764ba2);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                    margin-bottom: 10px; 
                }
                .subtitle { color: #666; font-size: 1.2rem; margin-bottom: 20px; }
                .version-badge {
                    display: inline-block;
                    background: #10b981;
                    color: white;
                    padding: 8px 16px;
                    border-radius: 25px;
                    font-size: 0.9rem;
                    font-weight: 600;
                }
                .steps { 
                    display: flex; 
                    justify-content: space-between; 
                    margin-bottom: 40px;
                    flex-wrap: wrap; 
                    gap: 10px; 
                }
                .step { 
                    flex: 1;
                    min-width: 120px;
                    padding: 15px 10px; 
                    border-radius: 12px; 
                    font-size: 0.9rem;
                    text-align: center;
                    background: #f8f9fa; 
                    color: #6c757d; 
                    border: 2px solid #e9ecef;
                    transition: all 0.3s ease;
                }
                .step.active { 
                    background: linear-gradient(135deg, #667eea, #764ba2); 
                    color: white; 
                    border-color: #667eea;
                    transform: translateY(-2px);
                    box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
                }
                .step.completed { 
                    background: #10b981; 
                    color: white; 
                    border-color: #10b981;
                }
                .btn { 
                    background: linear-gradient(135deg, #667eea, #764ba2); 
                    color: white; 
                    padding: 15px 30px; 
                    border: none;
                    border-radius: 8px; 
                    cursor: pointer; 
                    text-decoration: none;
                    display: inline-flex;
                    align-items: center;
                    gap: 8px;
                    font-size: 1rem; 
                    font-weight: 600;
                    transition: all 0.3s ease;
                }
                .btn:hover { 
                    transform: translateY(-2px);
                    box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
                }
                .btn-success { background: linear-gradient(135deg, #10b981, #059669); }
                .btn-danger { background: linear-gradient(135deg, #ef4444, #dc2626); }
                .alert { 
                    padding: 20px; 
                    border-radius: 12px; 
                    margin: 20px 0; 
                    border-left: 4px solid;
                    display: flex;
                    align-items: flex-start;
                    gap: 15px;
                }
                .alert-success { 
                    background: linear-gradient(135deg, #ecfdf5, #f0fdf4); 
                    border-color: #10b981; 
                    color: #065f46; 
                }
                .alert-danger { 
                    background: linear-gradient(135deg, #fef2f2, #fee2e2); 
                    border-color: #ef4444; 
                    color: #991b1b; 
                }
                .alert-warning { 
                    background: linear-gradient(135deg, #fffbeb, #fef3c7); 
                    border-color: #f59e0b; 
                    color: #92400e; 
                }
                .alert-info { 
                    background: linear-gradient(135deg, #eff6ff, #dbeafe); 
                    border-color: #3b82f6; 
                    color: #1e40af; 
                }
                .form-group { margin: 20px 0; }
                .form-group label { 
                    display: block; 
                    margin-bottom: 8px; 
                    font-weight: 600; 
                    color: #374151;
                }
                .form-group input, .form-group select, .form-group textarea { 
                    width: 100%; 
                    padding: 12px 16px; 
                    border: 2px solid #e5e7eb;
                    border-radius: 8px; 
                    font-size: 1rem;
                    transition: border-color 0.3s ease;
                }
                .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
                    outline: none;
                    border-color: #667eea;
                    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
                }
                .form-help { font-size: 0.875rem; color: #6b7280; margin-top: 6px; }
                .progress { 
                    background: #f1f5f9; 
                    border-radius: 10px; 
                    height: 8px; 
                    margin: 20px 0; 
                    overflow: hidden;
                }
                .progress-bar { 
                    background: linear-gradient(90deg, #667eea, #764ba2); 
                    height: 100%; 
                    border-radius: 10px;
                    transition: width 0.5s ease; 
                }
                .requirement { 
                    display: flex; 
                    justify-content: space-between; 
                    align-items: center;
                    padding: 15px 0; 
                    border-bottom: 1px solid #f1f5f9; 
                }
                .requirement:last-child { border-bottom: none; }
                .requirement-name { font-weight: 500; }
                .status-ok { color: #10b981; font-weight: 600; }
                .status-error { color: #ef4444; font-weight: 600; }
                .status-warning { color: #f59e0b; font-weight: 600; }
                .feature-list { 
                    background: #f8fafc; 
                    border-radius: 12px; 
                    padding: 20px; 
                    margin: 20px 0; 
                }
                .feature-list ul { margin: 10px 0 0 20px; line-height: 1.8; }
                .nodejs-info {
                    background: linear-gradient(135deg, #f0f9ff, #e0f2fe);
                    border: 2px solid #0ea5e9;
                    border-radius: 12px;
                    padding: 20px;
                    margin: 20px 0;
                }
                .loading { 
                    display: inline-block; 
                    width: 20px; 
                    height: 20px; 
                    border: 3px solid #f3f4f6; 
                    border-top: 3px solid #667eea; 
                    border-radius: 50%; 
                    animation: spin 1s linear infinite; 
                }
                @keyframes spin { 
                    0% { transform: rotate(0deg); } 
                    100% { transform: rotate(360deg); } 
                }
                .text-center { text-align: center; }
                .mt-4 { margin-top: 2rem; }
                .mb-4 { margin-bottom: 2rem; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="card">
                    <div class="header">
                        <div class="logo">🚀 PageForge</div>
                        <div class="subtitle">Installation Automatisée cPanel</div>
                        <span class="version-badge">v<?= $this->config['version'] ?></span>
                    </div>
                    
                    <div class="steps">
                        <?php
                        $currentStep = $_GET['step'] ?? 'welcome';
                        $stepKeys = array_keys($this->steps);
                        $currentIndex = array_search($currentStep, $stepKeys);
                        
                        foreach($this->steps as $key => $label) {
                            $index = array_search($key, $stepKeys);
                            $class = 'step';
                            if($index < $currentIndex) $class .= ' completed';
                            if($key === $currentStep) $class .= ' active';
                            echo "<div class='$class'>$label</div>";
                        }
                        ?>
                    </div>
        <?php
    }
    
    private function stepWelcome() {
        ?>
        <h3>🎉 Bienvenue dans l'installation de PageForge</h3>
        <p style="margin: 20px 0; line-height: 1.6; font-size: 1.1rem;">
            PageForge est un éditeur visuel de sites web professionnel avec interface moderne, 
            52 composants, système de templates avancé et export multi-format.
        </p>
        
        <div class="nodejs-info">
            <h4 style="color: #0ea5e9; margin-bottom: 15px;">🔧 Support Node.js cPanel</h4>
            <p style="margin-bottom: 15px;">
                <strong>Cette installation supporte le Node.js Selector de cPanel !</strong>
                Si votre hébergeur propose cet outil, vous pourrez :
            </p>
            <ul style="margin-left: 20px; line-height: 1.6;">
                <li>Sélectionner automatiquement la version Node.js recommandée</li>
                <li>Configurer l'environnement sans ligne de commande</li>
                <li>Bénéficier de performances optimales</li>
            </ul>
        </div>
        
        <div class="alert alert-warning">
            <div style="font-size: 1.5rem;">⚠️</div>
            <div>
                <strong>Prérequis importants :</strong>
                <ul style="margin: 10px 0 0 20px; line-height: 1.6;">
                    <li>Accès à votre cPanel avec File Manager</li>
                    <li>Base de données MySQL/PostgreSQL disponible</li>
                    <li>Fichier pageforge-build.zip uploadé</li>
                    <li>Node.js Selector (optionnel mais recommandé)</li>
                </ul>
            </div>
        </div>
        
        <div class="feature-list">
            <h4>📋 Ce que va installer cette procédure :</h4>
            <ul>
                <li>✅ Vérification automatique des prérequis système</li>
                <li>✅ Configuration Node.js via cPanel (si disponible)</li>
                <li>✅ Installation et configuration base de données</li>
                <li>✅ Extraction et déploiement des fichiers</li>
                <li>✅ Configuration automatique de l'environnement</li>
                <li>✅ Optimisation pour hébergement partagé</li>
            </ul>
        </div>
        
        <div class="text-center mt-4">
            <a href="?step=requirements" class="btn">Commencer l'installation</a>
        </div>
        <?php
    }
    
    private function stepRequirements() {
        $requirements = $this->checkRequirements();
        $allPassed = array_reduce($requirements, function($carry, $req) {
            return $carry && $req['status'];
        }, true);
        
        ?>
        <h3>🔍 Vérification des prérequis</h3>
        
        <div style="margin: 30px 0;">
            <?php foreach($requirements as $req): ?>
                <div class="requirement">
                    <div>
                        <div class="requirement-name"><?= $req['name'] ?></div>
                        <?php if(isset($req['current'])): ?>
                            <small style="color: #6b7280;">Actuel: <?= $req['current'] ?></small>
                        <?php endif; ?>
                    </div>
                    <span class="<?= $req['status'] ? 'status-ok' : 'status-error' ?>">
                        <?= $req['status'] ? '✅ OK' : '❌ ERREUR' ?>
                    </span>
                </div>
                <?php if(!$req['status'] && isset($req['help'])): ?>
                    <div class="alert alert-danger">
                        <div>❌</div>
                        <div><?= $req['help'] ?></div>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
        
        <?php if($allPassed): ?>
            <div class="alert alert-success">
                <div>✅</div>
                <div><strong>Excellent !</strong> Tous les prérequis sont satisfaits.</div>
            </div>
            <div class="text-center mt-4">
                <a href="?step=nodejs" class="btn">Continuer → Configuration Node.js</a>
            </div>
        <?php else: ?>
            <div class="alert alert-danger">
                <div>❌</div>
                <div>
                    <strong>Problème détecté :</strong> Certains prérequis ne sont pas satisfaits. 
                    Veuillez corriger les erreurs avant de continuer.
                </div>
            </div>
            <div class="text-center mt-4">
                <a href="?step=requirements" class="btn">Revérifier les prérequis</a>
            </div>
        <?php endif; ?>
        <?php
    }
    
    private function stepNodeJS() {
        $nodeInfo = $this->checkNodeJS();
        
        ?>
        <h3>🔧 Configuration Node.js</h3>
        
        <div class="nodejs-info">
            <h4 style="color: #0ea5e9; margin-bottom: 15px;">Node.js Selector cPanel</h4>
            <p>
                Si votre hébergeur propose Node.js Selector, suivez ces étapes dans cPanel :
            </p>
            <ol style="margin: 15px 0 0 20px; line-height: 1.8;">
                <li>Allez dans <strong>Node.js Selector</strong></li>
                <li>Cliquez sur <strong>"Create Application"</strong></li>
                <li>Sélectionnez <strong>Node.js version 16+</strong></li>
                <li>Définissez le <strong>Application root</strong> sur votre dossier</li>
                <li>Laissez le <strong>Application startup file</strong> vide pour l'instant</li>
                <li>Cliquez <strong>"Create"</strong></li>
            </ol>
        </div>
        
        <div style="margin: 30px 0;">
            <div class="requirement">
                <div class="requirement-name">État Node.js détecté</div>
                <span class="<?= $nodeInfo['available'] ? 'status-ok' : 'status-warning' ?>">
                    <?= $nodeInfo['available'] ? '✅ DISPONIBLE' : '⚠️ NON DÉTECTÉ' ?>
                </span>
            </div>
            
            <?php if($nodeInfo['available']): ?>
                <div class="requirement">
                    <div class="requirement-name">Version Node.js</div>
                    <span class="status-ok"><?= $nodeInfo['version'] ?></span>
                </div>
                <div class="requirement">
                    <div class="requirement-name">Version NPM</div>
                    <span class="status-ok"><?= $nodeInfo['npm_version'] ?></span>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if($nodeInfo['available']): ?>
            <div class="alert alert-success">
                <div>✅</div>
                <div><strong>Parfait !</strong> Node.js est configuré et fonctionnel.</div>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                <div>⚠️</div>
                <div>
                    <strong>Node.js non détecté.</strong> L'installation continuera en mode PHP uniquement.
                    Pour de meilleures performances, configurez Node.js via cPanel si disponible.
                </div>
            </div>
        <?php endif; ?>
        
        <div class="text-center mt-4">
            <a href="?step=database" class="btn">Continuer → Configuration Base de Données</a>
        </div>
        <?php
    }
    
    private function stepDatabase() {
        if($_POST) {
            $this->processDatabaseConfig();
            return;
        }
        ?>
        <h3>🗄️ Configuration Base de Données</h3>
        
        <div class="alert alert-info">
            <div>ℹ️</div>
            <div>
                <strong>Base de données requise :</strong> PageForge nécessite une base de données 
                MySQL ou PostgreSQL. Créez-la via votre cPanel avant de continuer.
            </div>
        </div>
        
        <form method="POST" style="margin: 30px 0;">
            <div class="form-group">
                <label>Type de base de données :</label>
                <select name="db_type" required onchange="updateDbFields()">
                    <option value="mysql">MySQL (recommandé pour cPanel)</option>
                    <option value="postgresql">PostgreSQL</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Host de la base de données :</label>
                <input type="text" name="db_host" value="localhost" required>
                <div class="form-help">Généralement 'localhost' pour les hébergements cPanel</div>
            </div>
            
            <div class="form-group" id="db_port_group">
                <label>Port :</label>
                <input type="number" name="db_port" value="3306" required id="db_port">
                <div class="form-help" id="port_help">Port MySQL (3306 par défaut)</div>
            </div>
            
            <div class="form-group">
                <label>Nom de la base de données :</label>
                <input type="text" name="db_name" required>
                <div class="form-help">Le nom de votre base de données créée dans cPanel</div>
            </div>
            
            <div class="form-group">
                <label>Nom d'utilisateur :</label>
                <input type="text" name="db_user" required>
                <div class="form-help">Utilisateur de la base de données</div>
            </div>
            
            <div class="form-group">
                <label>Mot de passe :</label>
                <input type="password" name="db_password" required>
            </div>
            
            <div class="text-center mt-4">
                <button type="submit" class="btn">
                    <span class="loading" id="test-loading" style="display: none;"></span>
                    Tester la connexion
                </button>
            </div>
        </form>
        
        <script>
        function updateDbFields() {
            const dbType = document.querySelector('select[name="db_type"]').value;
            const portField = document.getElementById('db_port');
            const portHelp = document.getElementById('port_help');
            
            if (dbType === 'postgresql') {
                portField.value = '5432';
                portHelp.textContent = 'Port PostgreSQL (5432 par défaut)';
            } else {
                portField.value = '3306';
                portHelp.textContent = 'Port MySQL (3306 par défaut)';
            }
        }
        
        document.querySelector('form').addEventListener('submit', function() {
            document.getElementById('test-loading').style.display = 'inline-block';
        });
        </script>
        <?php
    }
    
    private function stepFiles() {
        if($_POST && isset($_POST['install_files'])) {
            $this->installFiles();
            return;
        }
        
        ?>
        <h3>📁 Installation des Fichiers</h3>
        
        <div class="alert alert-warning">
            <div>📤</div>
            <div>
                <strong>Avant de continuer :</strong><br>
                Assurez-vous d'avoir uploadé le fichier <code>pageforge-build.zip</code> 
                dans le même dossier que ce script d'installation via File Manager cPanel.
            </div>
        </div>
        
        <?php
        $zipFile = 'pageforge-build.zip';
        if(file_exists($zipFile)):
        ?>
            <div class="alert alert-success">
                <div>✅</div>
                <div>
                    <strong>Fichier ZIP détecté :</strong> <?= $zipFile ?><br>
                    <small>Taille: <?= $this->formatBytes(filesize($zipFile)) ?></small>
                </div>
            </div>
            
            <div class="feature-list">
                <h4>📋 Contenu qui sera installé :</h4>
                <ul>
                    <li>Interface utilisateur React avec 52 composants</li>
                    <li>Serveur Node.js/Express optimisé</li>
                    <li>Base de données avec schémas Drizzle</li>
                    <li>Système de templates et d'export</li>
                    <li>Configuration cPanel optimisée</li>
                </ul>
            </div>
            
            <form method="POST" style="text-align: center; margin: 30px 0;">
                <input type="hidden" name="install_files" value="1">
                <button type="submit" class="btn">
                    <span class="loading" id="extract-loading" style="display: none;"></span>
                    Extraire et installer les fichiers
                </button>
            </form>
            
            <script>
            document.querySelector('form').addEventListener('submit', function() {
                document.getElementById('extract-loading').style.display = 'inline-block';
            });
            </script>
        <?php else: ?>
            <div class="alert alert-danger">
                <div>❌</div>
                <div>
                    <strong>Fichier ZIP non trouvé.</strong><br>
                    Veuillez uploader <code>pageforge-build.zip</code> dans ce dossier 
                    via File Manager cPanel puis actualiser cette page.
                </div>
            </div>
            
            <div class="text-center mt-4">
                <a href="?step=files" class="btn">Actualiser la page</a>
            </div>
        <?php endif; ?>
        <?php
    }
    
    private function stepConfig() {
        $this->generateEnvironmentFile();
        $this->generateHtaccess();
        $this->setupNodeJSConfig();
        
        ?>
        <h3>⚙️ Configuration Finale</h3>
        
        <div class="alert alert-success">
            <div>✅</div>
            <div>
                <strong>Configuration automatique terminée :</strong>
                <ul style="margin: 10px 0 0 20px; line-height: 1.6;">
                    <li>Fichier .env créé avec configuration base de données</li>
                    <li>Configuration .htaccess pour hébergement partagé</li>
                    <li>Configuration Node.js (si disponible)</li>
                    <li>Permissions fichiers définies</li>
                    <li>Structure projet optimisée</li>
                </ul>
            </div>
        </div>
        
        <?php if($this->checkNodeJS()['available']): ?>
            <div class="nodejs-info">
                <h4 style="color: #0ea5e9; margin-bottom: 15px;">🔧 Configuration Node.js terminée</h4>
                <p>
                    Si vous utilisez Node.js Selector dans cPanel, retournez dans l'interface 
                    et définissez le <strong>Application startup file</strong> sur : <code>server/index.js</code>
                </p>
            </div>
        <?php endif; ?>
        
        <div class="feature-list">
            <h4>📋 Dernières étapes manuelles :</h4>
            <ol style="margin: 15px 0 0 20px; line-height: 1.8;">
                <li><strong>Supprimer ce fichier d'installation</strong> (install-cpanel.php)</li>
                <li><strong>Vérifier les permissions</strong> des dossiers (755 recommandé)</li>
                <li><strong>Pointer votre domaine</strong> vers le dossier d'installation</li>
                <li><strong>Activer Node.js</strong> si vous utilisez Node.js Selector</li>
                <li><strong>Tester l'accès</strong> à votre nouveau site</li>
            </ol>
        </div>
        
        <div class="text-center mt-4">
            <a href="?step=complete" class="btn btn-success">Finaliser l'installation</a>
        </div>
        <?php
    }
    
    private function stepComplete() {
        ?>
        <h3>🎉 Installation Terminée avec Succès !</h3>
        
        <div class="alert alert-success">
            <div>🚀</div>
            <div><strong>PageForge v<?= $this->config['version'] ?> a été installé avec succès sur votre hébergement cPanel !</strong></div>
        </div>
        
        <div class="feature-list">
            <h4>🚀 Prochaines étapes :</h4>
            <ol style="margin: 15px 0 0 20px; line-height: 1.8;">
                <li><strong>Supprimez ce fichier d'installation</strong> pour des raisons de sécurité</li>
                <li><strong>Accédez à votre site</strong> : <a href="/" target="_blank" style="color: #667eea;">Ouvrir PageForge</a></li>
                <li><strong>Créez votre premier projet</strong> avec les templates intégrés</li>
                <li><strong>Explorez les 52 composants</strong> disponibles</li>
                <li><strong>Configurez vos préférences</strong> dans les paramètres</li>
            </ol>
        </div>
        
        <div class="nodejs-info" style="border-color: #10b981; background: linear-gradient(135deg, #ecfdf5, #f0fdf4);">
            <h4 style="color: #10b981; margin-bottom: 15px;">🔧 Configuration cPanel Node.js</h4>
            <p style="margin-bottom: 10px;">
                <strong>Si vous utilisez Node.js Selector :</strong>
            </p>
            <ul style="margin-left: 20px; line-height: 1.6;">
                <li>Définissez <strong>Application startup file</strong> : <code>server/index.js</code></li>
                <li>Redémarrez l'application dans Node.js Selector</li>
                <li>Vérifiez que l'application démarre correctement</li>
            </ul>
        </div>
        
        <div class="alert alert-info">
            <div>📞</div>
            <div>
                <strong>Support et Documentation :</strong><br>
                Consultez le fichier README.md inclus pour plus d'informations sur l'utilisation de PageForge.
                La documentation complète est disponible dans l'interface une fois connecté.
            </div>
        </div>
        
        <div class="text-center mt-4">
            <a href="/" class="btn btn-success" target="_blank">Ouvrir PageForge</a>
            <button onclick="deleteInstaller()" class="btn btn-danger" style="margin-left: 15px;">
                Supprimer l'installateur
            </button>
        </div>
        
        <script>
        function deleteInstaller() {
            if(confirm('Êtes-vous sûr de vouloir supprimer le fichier d\'installation ?\n\nCette action est irréversible.')) {
                const btn = event.target;
                btn.innerHTML = '<span class="loading"></span> Suppression...';
                btn.disabled = true;
                
                fetch('?action=delete_installer', {method: 'POST'})
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        alert('✅ Fichier d\'installation supprimé avec succès !');
                        window.location.href = '/';
                    } else {
                        alert('❌ Erreur lors de la suppression. Supprimez manuellement le fichier.');
                        btn.disabled = false;
                        btn.innerHTML = 'Supprimer l\'installateur';
                    }
                })
                .catch(error => {
                    alert('❌ Erreur lors de la suppression. Supprimez manuellement le fichier.');
                    btn.disabled = false;
                    btn.innerHTML = 'Supprimer l\'installateur';
                });
            }
        }
        </script>
        <?php
    }
    
    private function checkRequirements() {
        $requirements = [];
        
        // PHP Version
        $phpVersion = PHP_VERSION;
        $requirements[] = [
            'name' => 'Version PHP >= ' . $this->config['min_php'],
            'current' => $phpVersion,
            'status' => version_compare($phpVersion, $this->config['min_php'], '>='),
            'help' => 'Veuillez mettre à jour PHP vers une version ' . $this->config['min_php'] . '+ via cPanel.'
        ];
        
        // Extensions PHP
        foreach($this->config['required_extensions'] as $ext) {
            $loaded = extension_loaded($ext);
            $requirements[] = [
                'name' => "Extension PHP: $ext",
                'status' => $loaded,
                'help' => "L'extension $ext doit être activée. Contactez votre hébergeur si non disponible."
            ];
        }
        
        // Permissions d'écriture
        $requirements[] = [
            'name' => 'Permissions d\'écriture du dossier',
            'status' => is_writable('.'),
            'help' => 'Le dossier doit avoir les permissions d\'écriture (755 recommandé).'
        ];
        
        // Espace disque (estimation)
        $freeSpace = disk_free_space('.');
        $requirements[] = [
            'name' => 'Espace disque disponible (>100MB)',
            'current' => $this->formatBytes($freeSpace),
            'status' => $freeSpace > (100 * 1024 * 1024),
            'help' => 'Au moins 100MB d\'espace libre requis pour l\'installation.'
        ];
        
        return $requirements;
    }
    
    private function checkNodeJS() {
        $nodeInfo = [
            'available' => false,
            'version' => null,
            'npm_version' => null
        ];
        
        // Tenter de détecter Node.js
        $nodeVersion = @shell_exec('node --version 2>/dev/null');
        $npmVersion = @shell_exec('npm --version 2>/dev/null');
        
        if($nodeVersion && trim($nodeVersion)) {
            $nodeInfo['available'] = true;
            $nodeInfo['version'] = trim($nodeVersion);
            $nodeInfo['npm_version'] = $npmVersion ? trim($npmVersion) : 'Non détecté';
        }
        
        return $nodeInfo;
    }
    
    private function processDatabaseConfig() {
        try {
            $dbType = $_POST['db_type'] ?? 'mysql';
            $host = $_POST['db_host'] ?? 'localhost';
            $port = $_POST['db_port'] ?? ($dbType === 'postgresql' ? 5432 : 3306);
            $database = $_POST['db_name'] ?? '';
            $username = $_POST['db_user'] ?? '';
            $password = $_POST['db_password'] ?? '';
            
            // Test de connexion
            if($dbType === 'postgresql') {
                $dsn = "pgsql:host=$host;port=$port;dbname=$database";
            } else {
                $dsn = "mysql:host=$host;port=$port;dbname=$database;charset=utf8mb4";
            }
            
            $pdo = new PDO($dsn, $username, $password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_TIMEOUT => 10
            ]);
            
            // Sauvegarder la configuration
            $_SESSION['db_config'] = [
                'type' => $dbType,
                'host' => $host,
                'port' => $port,
                'database' => $database,
                'username' => $username,
                'password' => $password
            ];
            
            ?>
            <div class="alert alert-success">
                <div>✅</div>
                <div><strong>Connexion réussie !</strong> La base de données est accessible.</div>
            </div>
            <div class="text-center mt-4">
                <a href="?step=files" class="btn">Continuer → Installation des fichiers</a>
            </div>
            <?php
            
        } catch(PDOException $e) {
            ?>
            <div class="alert alert-danger">
                <div>❌</div>
                <div>
                    <strong>Erreur de connexion :</strong><br>
                    <?= htmlspecialchars($e->getMessage()) ?><br><br>
                    Vérifiez vos paramètres de connexion et que la base de données existe.
                </div>
            </div>
            <div class="text-center mt-4">
                <a href="?step=database" class="btn">Réessayer</a>
            </div>
            <?php
        }
    }
    
    private function installFiles() {
        try {
            $zipFile = 'pageforge-build.zip';
            
            if(!file_exists($zipFile)) {
                throw new Exception("Fichier ZIP non trouvé");
            }
            
            // Extraire le ZIP
            $zip = new ZipArchive;
            if ($zip->open($zipFile) === TRUE) {
                $zip->extractTo('./');
                $zip->close();
                
                // Définir les permissions
                $this->setFilePermissions();
                
                ?>
                <div class="alert alert-success">
                    <div>✅</div>
                    <div><strong>Extraction réussie !</strong> Tous les fichiers ont été installés.</div>
                </div>
                <div class="text-center mt-4">
                    <a href="?step=config" class="btn">Continuer → Configuration finale</a>
                </div>
                <?php
                
            } else {
                throw new Exception("Impossible d'ouvrir le fichier ZIP");
            }
            
        } catch(Exception $e) {
            ?>
            <div class="alert alert-danger">
                <div>❌</div>
                <div>
                    <strong>Erreur d'installation :</strong><br>
                    <?= htmlspecialchars($e->getMessage()) ?>
                </div>
            </div>
            <div class="text-center mt-4">
                <a href="?step=files" class="btn">Réessayer</a>
            </div>
            <?php
        }
    }
    
    private function setFilePermissions() {
        $dirs = ['client', 'server', 'shared', 'docs', 'uploads'];
        foreach($dirs as $dir) {
            if(is_dir($dir)) {
                chmod($dir, 0755);
            }
        }
        
        $files = glob('*.{js,json,md}', GLOB_BRACE);
        foreach($files as $file) {
            chmod($file, 0644);
        }
    }
    
    private function generateEnvironmentFile() {
        if(!isset($_SESSION['db_config'])) return;
        
        $dbConfig = $_SESSION['db_config'];
        $envContent = "# PageForge Configuration - cPanel\n";
        $envContent .= "NODE_ENV=production\n";
        $envContent .= "PORT=3000\n\n";
        
        $envContent .= "# Base de données\n";
        if($dbConfig['type'] === 'postgresql') {
            $envContent .= "DATABASE_URL=postgresql://{$dbConfig['username']}:{$dbConfig['password']}@{$dbConfig['host']}:{$dbConfig['port']}/{$dbConfig['database']}\n";
        } else {
            $envContent .= "DATABASE_URL=mysql://{$dbConfig['username']}:{$dbConfig['password']}@{$dbConfig['host']}:{$dbConfig['port']}/{$dbConfig['database']}\n";
        }
        
        $envContent .= "\n# Configuration cPanel\n";
        $envContent .= "CPANEL_OPTIMIZED=true\n";
        $envContent .= "STATIC_HOSTING=true\n";
        
        file_put_contents('.env', $envContent);
    }
    
    private function generateHtaccess() {
        $htaccessContent = "# PageForge - Configuration cPanel\n";
        $htaccessContent .= "RewriteEngine On\n\n";
        
        $htaccessContent .= "# Redirection vers Node.js app si disponible\n";
        $htaccessContent .= "RewriteCond %{REQUEST_FILENAME} !-f\n";
        $htaccessContent .= "RewriteCond %{REQUEST_FILENAME} !-d\n";
        $htaccessContent .= "RewriteRule ^(.*)$ index.html [L]\n\n";
        
        $htaccessContent .= "# Sécurité\n";
        $htaccessContent .= "<Files \".env\">\nOrder Allow,Deny\nDeny from all\n</Files>\n";
        $htaccessContent .= "<Files \"install-*.php\">\nOrder Allow,Deny\nDeny from all\n</Files>\n\n";
        
        $htaccessContent .= "# Compression\n";
        $htaccessContent .= "<IfModule mod_deflate.c>\n";
        $htaccessContent .= "  AddOutputFilterByType DEFLATE text/html text/css text/javascript application/javascript application/json\n";
        $htaccessContent .= "</IfModule>\n\n";
        
        $htaccessContent .= "# Cache\n";
        $htaccessContent .= "<IfModule mod_expires.c>\n";
        $htaccessContent .= "  ExpiresActive On\n";
        $htaccessContent .= "  ExpiresByType text/css \"access plus 1 month\"\n";
        $htaccessContent .= "  ExpiresByType application/javascript \"access plus 1 month\"\n";
        $htaccessContent .= "  ExpiresByType image/* \"access plus 1 month\"\n";
        $htaccessContent .= "</IfModule>\n";
        
        file_put_contents('.htaccess', $htaccessContent);
    }
    
    private function setupNodeJSConfig() {
        // Créer package.json pour Node.js Selector si nécessaire
        if(!file_exists('package.json')) {
            $packageJson = [
                'name' => 'pageforge-cpanel',
                'version' => $this->config['version'],
                'description' => 'PageForge - Visual Website Builder',
                'main' => 'server/index.js',
                'scripts' => [
                    'start' => 'node server/index.js',
                    'build' => 'npm run build:client && npm run build:server',
                    'build:client' => 'vite build',
                    'build:server' => 'tsc --build'
                ],
                'engines' => [
                    'node' => '>=16.0.0'
                ]
            ];
            
            file_put_contents('package.json', json_encode($packageJson, JSON_PRETTY_PRINT));
        }
    }
    
    private function formatBytes($size, $precision = 2) {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        
        for ($i = 0; $size >= 1024 && $i < count($units) - 1; $i++) {
            $size /= 1024;
        }
        
        return round($size, $precision) . ' ' . $units[$i];
    }
    
    private function renderFooter() {
        ?>
                </div>
            </div>
            
            <div style="text-align: center; color: rgba(255,255,255,0.8); margin: 20px 0; font-size: 0.9rem;">
                PageForge v<?= $this->config['version'] ?> - Installation cPanel Automatisée
            </div>
        </body>
        </html>
        <?php
    }
}

// Démarrer l'installation
if(!session_id()) session_start();
$installer = new PageForgeInstaller();
$installer->run();
?>