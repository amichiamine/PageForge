# PageForge v2.0.0 - Package Windows

## Informations
- **Type**: Installation locale Windows
- **Prérequis**: PHP 7.4+, Node.js 18+
- **Installation**: Interface web PHP
- **Version**: 2.0.0
- **Date**: 2025-08-04 08:13:35

## Fonctionnalités
- Détection automatique Windows
- Installation Node.js guidée
- Configuration SQLite/PostgreSQL
- Script de démarrage inclus

## Support
Pour toute question ou problème, consultez la documentation incluse.
